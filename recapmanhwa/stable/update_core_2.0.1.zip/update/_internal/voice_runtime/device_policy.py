"""Central Voice Pro device policy. Engine capability first; never force CUDA globally."""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass
from typing import Any

logger = logging.getLogger("recap.voice.device")

FORCE_NO_CUDA_ENVS = (
    "LOCALVOICE_FORCE_NO_CUDA",
    "RECAP_MANHWA_FORCE_NO_CUDA",
)

# Per-engine free-VRAM floors before a CUDA load is attempted.
VRAM_MIN_FREE_MB: dict[str, float] = {
    "qwen": 4096.0,
    "vox_cuda": 8192.0,
}

CPU_ONLY_ENGINES = frozenset({"vieneu", "moss", "vox_q4"})
CUDA_CAPABLE_ENGINES = frozenset({"qwen", "vox_cuda"})

FALLBACK_NOTICE = "Không thể sử dụng GPU cho giọng này. Hệ thống đã chuyển sang CPU."

_cuda_locked_cpu = False
_cuda_lock_reason = ""


@dataclass(frozen=True)
class DeviceDecision:
    engine: str
    device: str
    reason: str
    cuda_available: bool
    cuda_supported: bool
    precision: str
    cpu_fallback: bool
    vram_free_mb: float | None = None
    vram_threshold_mb: float | None = None
    model_family: str = ""
    backend: str = ""

    def summary_lines(self) -> list[str]:
        return [
            f"LANGUAGE: {{language}}",
            f"VOICE: {{voice}}",
            f"ENGINE: {self.engine}",
            f"BACKEND: {self.backend}",
            f"CUDA AVAILABLE: {'YES' if self.cuda_available else 'NO'}",
            f"CUDA SUPPORTED BY ENGINE: {'YES' if self.cuda_supported else 'NO'}",
            f"SELECTED DEVICE: {self.device.upper()}",
            f"SELECTION REASON: {self.reason}",
        ]


def cuda_forced_off() -> bool:
    for name in FORCE_NO_CUDA_ENVS:
        if os.environ.get(name, "").strip().lower() in {"1", "true", "yes", "on"}:
            return True
    return False


def mark_cuda_unavailable(reason: str) -> None:
    global _cuda_locked_cpu, _cuda_lock_reason
    _cuda_locked_cpu = True
    _cuda_lock_reason = (reason or "cuda_failure").strip() or "cuda_failure"
    logger.warning("CUDA locked off for remaining worker job: %s", _cuda_lock_reason)


def reset_cuda_lock() -> None:
    global _cuda_locked_cpu, _cuda_lock_reason
    _cuda_locked_cpu = False
    _cuda_lock_reason = ""


def cuda_locked_cpu() -> bool:
    return _cuda_locked_cpu


def cuda_lock_reason() -> str:
    return _cuda_lock_reason


def engine_supports_cuda(engine: str) -> bool:
    name = str(engine or "").strip()
    if name in CPU_ONLY_ENGINES:
        return False
    return name in CUDA_CAPABLE_ENGINES


def backend_for(engine: str) -> str:
    if engine == "vieneu":
        return "onnxruntime"
    if engine in {"qwen", "vox_cuda"}:
        return "pytorch"
    return "unknown"


def model_family_for(engine: str) -> str:
    try:
        from config.edition import engine_version

        return engine_version(engine)
    except Exception:
        mapping = {
            "vieneu": "vieneu-3.3.0-onnx-fp32",
            "qwen": "gwen-tts-0.6B",
            "vox_cuda": "voxcpm2-pytorch-32279eff",
        }
        return mapping.get(engine, engine)


def _vram_free_mb() -> float | None:
    try:
        from voice.capability import gpu_memory_mb

        info = gpu_memory_mb()
        value = info.get("vram_free_mb")
        if isinstance(value, (int, float)):
            return float(value)
    except Exception:
        logger.debug("VRAM probe failed", exc_info=True)
    return None


def _torch_cuda_usable() -> bool:
    if cuda_forced_off() or _cuda_locked_cpu:
        return False
    try:
        from voice.pro_deps import bootstrap_pro_deps

        bootstrap_pro_deps()
        import torch

        return bool(torch.cuda.is_available())
    except Exception:
        logger.debug("torch CUDA probe failed", exc_info=True)
        return False


def _nvidia_present() -> bool:
    if cuda_forced_off():
        return False
    try:
        from voice.capability import nvidia_present

        return bool(nvidia_present())
    except Exception:
        return False


def is_cuda_error(exc: BaseException) -> bool:
    text = f"{type(exc).__name__} {exc}".lower()
    markers = (
        "cuda",
        "out of memory",
        "oom",
        "cublas",
        "cudnn",
        "gpu_oom",
        "cannot allocate",
        "device-side assert",
    )
    return any(marker in text for marker in markers)


def release_cuda_memory() -> None:
    try:
        import gc

        gc.collect()
    except Exception:
        pass
    try:
        import torch

        if torch.cuda.is_available():
            torch.cuda.empty_cache()
            torch.cuda.synchronize()
    except Exception:
        logger.debug("CUDA cache release failed", exc_info=True)


def resolve_tts_device(
    engine: str,
    model: str | None = None,
    voice: str | None = None,
    runtime_capabilities: dict[str, Any] | None = None,
    hardware: Any | None = None,
    language: str | None = None,
) -> DeviceDecision:
    """Return cpu/cuda and the exact reason. Does not load models."""
    del model, voice, language
    name = str(engine or "").strip() or "vieneu"
    supported = engine_supports_cuda(name)
    backend = backend_for(name)
    family = model_family_for(name)
    caps = runtime_capabilities or {}

    if name == "vieneu" or name in CPU_ONLY_ENGINES:
        return DeviceDecision(
            engine=name,
            device="cpu",
            reason="VieNeu ONNX CPU-only",
            cuda_available=False,
            cuda_supported=False,
            precision="fp32",
            cpu_fallback=True,
            model_family=family,
            backend=backend,
        )

    forced = bool(caps.get("force_cpu")) or cuda_forced_off()
    nvidia = bool(caps.get("nvidia_present")) if "nvidia_present" in caps else _nvidia_present()
    if hardware is not None and not nvidia:
        nvidia = bool(getattr(hardware, "cuda_available", False))
    torch_ok = bool(caps.get("torch_cuda")) if "torch_cuda" in caps else False
    if supported and not forced and nvidia and "torch_cuda" not in caps:
        torch_ok = _torch_cuda_usable()
    cuda_available = bool(nvidia and torch_ok and not forced and not _cuda_locked_cpu)

    if not supported:
        return DeviceDecision(
            engine=name,
            device="cpu",
            reason="engine does not support CUDA",
            cuda_available=cuda_available,
            cuda_supported=False,
            precision="fp32",
            cpu_fallback=True,
            model_family=family,
            backend=backend,
        )
    if os.environ.get("RECAP_MANHWA_CUDA_INJECT_FAIL", "").strip() == "1":
        mark_cuda_unavailable("injected CUDA init failure")
        return DeviceDecision(
            engine=name,
            device="cpu",
            reason="CUDA initialization failed",
            cuda_available=False,
            cuda_supported=True,
            precision="fp32",
            cpu_fallback=True,
            model_family=family,
            backend=backend,
        )
    if forced:
        return DeviceDecision(
            engine=name,
            device="cpu",
            reason="CUDA forced off",
            cuda_available=False,
            cuda_supported=True,
            precision="fp32",
            cpu_fallback=True,
            model_family=family,
            backend=backend,
        )
    if _cuda_locked_cpu:
        return DeviceDecision(
            engine=name,
            device="cpu",
            reason=f"CUDA skipped after prior failure: {_cuda_lock_reason or 'cuda_failure'}",
            cuda_available=False,
            cuda_supported=True,
            precision="fp32",
            cpu_fallback=True,
            model_family=family,
            backend=backend,
        )
    if not nvidia:
        return DeviceDecision(
            engine=name,
            device="cpu",
            reason="no NVIDIA GPU",
            cuda_available=False,
            cuda_supported=True,
            precision="fp32",
            cpu_fallback=True,
            model_family=family,
            backend=backend,
        )
    if not torch_ok:
        return DeviceDecision(
            engine=name,
            device="cpu",
            reason="CUDA initialization failed",
            cuda_available=False,
            cuda_supported=True,
            precision="fp32",
            cpu_fallback=True,
            model_family=family,
            backend=backend,
        )

    threshold = VRAM_MIN_FREE_MB.get(name)
    free = _vram_free_mb()
    if hardware is not None and free is None:
        value = getattr(hardware, "vram_available_mb", None)
        if isinstance(value, (int, float)):
            free = float(value)
    if threshold is not None and free is not None and free < threshold:
        return DeviceDecision(
            engine=name,
            device="cpu",
            reason=f"CUDA SKIPPED: insufficient free VRAM ({free:.0f}MB < {threshold:.0f}MB)",
            cuda_available=True,
            cuda_supported=True,
            precision="fp32",
            cpu_fallback=True,
            vram_free_mb=free,
            vram_threshold_mb=threshold,
            model_family=family,
            backend=backend,
        )

    precision = "fp32"
    if name == "qwen":
        bf16 = bool(getattr(hardware, "bf16_supported", False)) if hardware is not None else False
        if not hardware:
            try:
                from voice.hardware import HardwareDetector

                bf16 = bool(HardwareDetector().detect().bf16_supported)
            except Exception:
                bf16 = False
        precision = "bf16" if bf16 else "fp16"
    reason = (
        "Qwen PyTorch CUDA available"
        if name == "qwen"
        else "VoxCPM2 PyTorch CUDA available"
    )
    return DeviceDecision(
        engine=name,
        device="cuda",
        reason=reason,
        cuda_available=True,
        cuda_supported=True,
        precision=precision,
        cpu_fallback=True,
        vram_free_mb=free,
        vram_threshold_mb=threshold,
        model_family=family,
        backend=backend,
    )


def to_engine_runtime_config(decision: DeviceDecision) -> Any:
    from voice.runtime import EngineRuntimeConfig

    cpu_fallback_used = decision.device == "cpu" and decision.cuda_supported
    return EngineRuntimeConfig(
        requested_mode=decision.device,
        resolved_device=decision.device,
        precision=decision.precision,
        low_vram=False,
        optimize=False,
        load_denoiser=False,
        empty_cache_after_synth=decision.engine != "vieneu",
        cpu_fallback_used=cpu_fallback_used,
        recommend_lightweight_engine=False,
        reason=decision.reason,
    )
