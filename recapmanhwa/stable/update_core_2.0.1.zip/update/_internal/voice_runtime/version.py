"""Versioned quality identity for the shared TTS Studio Pro runtime boundary."""

from __future__ import annotations

RUNTIME_VERSION = "4B1.1"
BACKEND_ID = "tts_studio_pro"
QUALITY_FINGERPRINT = (
    "pro-routes-v1|engine-limits-v1|punct-v1|audio-cache-v3|"
    "export-loudnorm-16lufs-1.5tp|native-sample-rate"
)

