"""Patch Pro engine selection at runtime. Does not edit production pro_src files."""

from __future__ import annotations

import logging
from typing import Any

from voice_runtime.device_policy import (
    FALLBACK_NOTICE,
    is_cuda_error,
    mark_cuda_unavailable,
    release_cuda_memory,
    resolve_tts_device,
    to_engine_runtime_config,
)

logger = logging.getLogger("recap.voice.hybrid")

_APPLIED = False


def apply_hybrid_hooks() -> None:
    global _APPLIED
    if _APPLIED:
        return
    import voice.engine_manager as engine_manager_mod
    import voice.engines.qwen_engine as qwen_mod
    import voice.engines.vox_cuda_engine as vox_mod
    import voice.runtime as runtime_mod
    from voice.local_engine import VoxCPM2Engine

    def resolve_runtime_config(hardware, settings, engine_name: str = "vieneu"):
        del settings
        decision = resolve_tts_device(engine_name, hardware=hardware)
        logger.info(
            "DEVICE POLICY engine=%s device=%s reason=%s",
            decision.engine,
            decision.device,
            decision.reason,
        )
        return to_engine_runtime_config(decision)

    runtime_mod.resolve_runtime_config = resolve_runtime_config

    def get_engine(self, language: str | None = None, engine_name: str | None = None):
        name = self.resolve_name(language, engine_name)
        self._unload_other_families(name)
        self.runtime = resolve_runtime_config(self.hardware, self.settings, name)
        engine = self._engines.get(name)
        if engine is None:
            engine = self._create(name)
            self._engines[name] = engine
        elif getattr(engine, "runtime", None) is not None:
            engine.runtime = self.runtime
        if not engine.is_loaded:
            engine.load()
        return engine

    engine_manager_mod.VoiceEngineManager.get_engine = get_engine

    _qwen_load = qwen_mod.QwenEngine.load

    def qwen_load(self) -> None:
        if self._model is not None:
            return
        decision = resolve_tts_device(self.name, hardware=self.hardware)
        self.runtime = to_engine_runtime_config(decision)
        try:
            _qwen_load(self)
            _assert_qwen_device(self, decision.device)
            return
        except Exception as exc:
            if decision.device != "cuda" or not is_cuda_error(exc):
                raise
            logger.warning("Qwen CUDA load/init failed; falling back to CPU: %s", exc)
            mark_cuda_unavailable(str(exc))
            self.close()
            release_cuda_memory()
            self.runtime = to_engine_runtime_config(
                resolve_tts_device(self.name, hardware=self.hardware)
            )
            _qwen_load(self)
            self._cpu_fallback_notice = FALLBACK_NOTICE

    qwen_mod.QwenEngine.load = qwen_load

    def vox_load(self) -> None:
        from voice.pro_deps import bootstrap_pro_deps

        decision = resolve_tts_device(self.name, hardware=self.hardware)
        self.runtime = to_engine_runtime_config(decision)
        bootstrap_pro_deps()
        if decision.device != "cuda":
            logger.info("VoxCPM2 CPU fallback reason=%s", decision.reason)
            VoxCPM2Engine.load(self)
            self._cpu_fallback_notice = FALLBACK_NOTICE if decision.cuda_supported else ""
            return
        try:
            VoxCPM2Engine.load(self)
            device = str(getattr(self, "runtime_device", "") or "").lower()
            if "cuda" not in device:
                raise RuntimeError(f"VoxCPM2 loaded on {device}, expected cuda")
            logger.info("VoxCPM2 CUDA ready device=%s model=%s", self.runtime_device, self.model_id)
            return
        except Exception as exc:
            logger.warning("VoxCPM2 CUDA load failed; falling back to CPU: %s", exc)
            mark_cuda_unavailable(str(exc))
            self.close()
            release_cuda_memory()
            self.runtime = to_engine_runtime_config(
                resolve_tts_device(self.name, hardware=self.hardware)
            )
            VoxCPM2Engine.load(self)
            self._cpu_fallback_notice = FALLBACK_NOTICE

    vox_mod.VoxCudaEngine.load = vox_load
    _APPLIED = True
    logger.info("Hybrid device hooks applied")


def _assert_qwen_device(engine: Any, expected: str) -> None:
    if expected != "cuda":
        return
    model = getattr(engine, "_model", None)
    if model is None:
        return
    try:
        import torch

        candidate = model
        for attr in ("model", "talker", "token2wav"):
            inner = getattr(candidate, attr, None)
            if inner is not None:
                candidate = inner
        params = None
        if hasattr(candidate, "parameters"):
            params = next(candidate.parameters(), None)
        if params is not None and getattr(params, "device", None) is not None:
            if params.device.type != "cuda":
                raise RuntimeError(f"Qwen tensors on {params.device}, expected cuda")
        elif torch.cuda.is_available() and torch.cuda.memory_allocated() <= 0:
            raise RuntimeError("Qwen CUDA selected but no GPU memory allocated")
    except StopIteration:
        return
