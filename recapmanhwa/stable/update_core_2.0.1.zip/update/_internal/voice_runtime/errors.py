"""Structured errors returned by the shared Pro runtime."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class RuntimeErrorPayload:
    code: str
    message: str
    details: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return {
            "code": self.code,
            "message": self.message,
            "details": self.details,
        }


class ProVoiceRuntimeError(RuntimeError):
    def __init__(self, code: str, message: str, **details: Any) -> None:
        super().__init__(message)
        self.payload = RuntimeErrorPayload(code, message, details)


def classify_exception(exc: BaseException) -> RuntimeErrorPayload:
    if isinstance(exc, ProVoiceRuntimeError):
        return exc.payload
    message = str(exc).strip() or exc.__class__.__name__
    lower = message.casefold()
    if isinstance(exc, MemoryError) or "out of memory" in lower or "cuda oom" in lower or "cannot allocate" in lower:
        code = "gpu_oom"
    elif "cuda" in lower:
        code = "cuda_failure"
    elif "cpu" in lower and "fallback" in lower:
        code = "cpu_fallback_failure"
    elif "model" in lower and ("missing" in lower or "not found" in lower):
        code = "missing_model"
    elif "voice" in lower and ("missing" in lower or "not found" in lower):
        code = "unsupported_voice"
    elif "language" in lower or "locale" in lower:
        code = "unsupported_language"
    elif "export" in lower or "ffmpeg" in lower:
        code = "export_failure"
    elif "duration" in lower or "ffprobe" in lower:
        code = "duration_read_failure"
    elif "sea_g2p" in lower and (
        "fingerprint" in lower or "version" in lower or "different" in lower
    ):
        code = "runtime_dependency_version_mismatch"
    elif "sea_g2p" in lower or "runtime dependency" in lower:
        code = "missing_runtime_dependency"
    elif "load" in lower or "initial" in lower or "import" in lower:
        code = "backend_init_failure"
    else:
        code = "synthesis_failure"
    return RuntimeErrorPayload(code, message, {"exception_type": exc.__class__.__name__})

