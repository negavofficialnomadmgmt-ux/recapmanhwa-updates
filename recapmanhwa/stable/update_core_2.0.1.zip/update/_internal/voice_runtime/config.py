"""Path resolution for the shared, versioned TTS Studio Pro runtime."""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from voice_runtime.errors import ProVoiceRuntimeError


@dataclass(frozen=True)
class ProRuntimeConfig:
    version: int
    source_root: Path
    built_root: Path
    staging_root: Path
    python_executable: Path
    models_dir: Path
    voices_dir: Path
    pydeps_dir: Path
    ffmpeg_dir: Path
    sea_g2p_package_dir: Path

    def to_dict(self) -> dict[str, Any]:
        return {
            "version": self.version,
            "source_root": str(self.source_root),
            "built_root": str(self.built_root),
            "staging_root": str(self.staging_root),
            "python_executable": str(self.python_executable),
            "models_dir": str(self.models_dir),
            "voices_dir": str(self.voices_dir),
            "pydeps_dir": str(self.pydeps_dir),
            "ffmpeg_dir": str(self.ffmpeg_dir),
            "sea_g2p_package_dir": str(self.sea_g2p_package_dir),
        }


def _resolve(raw: object, *, install_root: Path) -> Path:
    path = Path(str(raw or "")).expanduser()
    if not path.is_absolute():
        path = install_root / path
    return path.resolve()


def load_runtime_config(path: Path) -> ProRuntimeConfig:
    config_path = Path(path).resolve()
    if not config_path.is_file():
        raise ProVoiceRuntimeError(
            "missing_voice_runtime",
            f"Pro voice runtime config not found: {config_path}",
        )
    try:
        raw = json.loads(config_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ProVoiceRuntimeError(
            "missing_voice_runtime",
            f"Cannot read Pro voice runtime config: {exc}",
        ) from exc
    if not isinstance(raw, dict):
        raise ProVoiceRuntimeError("missing_voice_runtime", "Pro runtime config must be an object.")

    install_root = config_path.parents[2]
    config = ProRuntimeConfig(
        version=int(raw.get("version") or 1),
        source_root=_resolve(raw.get("source_root"), install_root=install_root),
        built_root=_resolve(raw.get("built_root"), install_root=install_root),
        staging_root=_resolve(raw.get("staging_root"), install_root=install_root),
        python_executable=_resolve(raw.get("python_executable"), install_root=install_root),
        models_dir=_resolve(raw.get("models_dir"), install_root=install_root),
        voices_dir=_resolve(raw.get("voices_dir"), install_root=install_root),
        pydeps_dir=_resolve(raw.get("pydeps_dir"), install_root=install_root),
        ffmpeg_dir=_resolve(raw.get("ffmpeg_dir"), install_root=install_root),
        sea_g2p_package_dir=_resolve(
            raw.get("sea_g2p_package_dir"),
            install_root=install_root,
        ),
    )
    validate_runtime_config(config)
    return config


def validate_runtime_config(config: ProRuntimeConfig) -> None:
    runtime_checks = {
        "canonical Pro source": config.source_root / "voice" / "engine_manager.py",
        "VoiceLibrary": config.source_root / "voice" / "library_service.py",
        "run_batch_job": config.source_root / "voice" / "batch.py",
        "export_job": config.source_root / "voice" / "export.py",
        "Pro app config": config.source_root / "config" / "app.yaml",
        "runtime Python": config.python_executable,
        "Pro pydeps": config.pydeps_dir / "torch",
        "FFmpeg": config.ffmpeg_dir / ("ffmpeg.exe" if os.name == "nt" else "ffmpeg"),
        "FFprobe": config.ffmpeg_dir / ("ffprobe.exe" if os.name == "nt" else "ffprobe"),
    }
    runtime_missing = [
        f"{label}: {path}" for label, path in runtime_checks.items() if not path.exists()
    ]
    if not config.built_root.is_dir():
        runtime_missing.append(f"reference built runtime: {config.built_root}")
    if runtime_missing:
        raise ProVoiceRuntimeError(
            "missing_voice_runtime",
            "TTS Studio Pro runtime is incomplete.",
            missing=runtime_missing,
        )

    staging_missing: list[str] = []
    if not config.staging_root.is_dir():
        staging_missing.append(f"canonical .localvoice staging: {config.staging_root}")
    if not config.voices_dir.is_dir():
        staging_missing.append(f"voice staging: {config.voices_dir}")
    if staging_missing:
        raise ProVoiceRuntimeError(
            "missing_voice_staging",
            "Canonical TTS Studio Pro voice staging is incomplete.",
            missing=staging_missing,
        )

    model_checks = {
        "Qwen model": config.models_dir / "qwen" / "gwen-tts-0.6B" / "model.safetensors",
        "VoxCPM2 model": config.models_dir / "voxcpm2" / "model.safetensors",
        "VieNeu model": config.models_dir / "vieneu",
    }
    model_missing = [
        f"{label}: {path}" for label, path in model_checks.items() if not path.exists()
    ]
    if model_missing:
        raise ProVoiceRuntimeError(
            "missing_model",
            "One or more frozen TTS Studio Pro models are missing.",
            missing=model_missing,
        )

    from voice_runtime.sea_g2p_loader import validate_sea_g2p_package

    validate_sea_g2p_package(config.sea_g2p_package_dir)


def runtime_environment(
    config: ProRuntimeConfig,
    *,
    work_dir: Path,
    cache_dir: Path,
    output_dir: Path,
    logs_dir: Path,
) -> dict[str, str]:
    source_voice_sources = config.staging_root / "voice_sources"
    pronunciation = config.source_root / "config" / "pronunciation"
    return {
        "LOCALVOICE_ROOT": str(config.source_root),
        "LOCALVOICE_PACKAGED": "0",
        "LOCALVOICE_EDITION": "PRO",
        "LOCALVOICE_PYDEPS": str(config.pydeps_dir),
        "LOCALVOICE_DOWNLOAD_MODELS": "0",
        "LOCALVOICE_MODELS_DIR": str(config.models_dir),
        "LOCALVOICE_VOICES_DIR": str(config.voices_dir),
        "LOCALVOICE_VOICE_SOURCES_DIR": str(source_voice_sources),
        "LOCALVOICE_CACHE_DIR": str(Path(cache_dir).resolve()),
        "LOCALVOICE_WORK_DIR": str(Path(work_dir).resolve()),
        "LOCALVOICE_OUTPUT_DIR": str(Path(output_dir).resolve()),
        "LOCALVOICE_LOGS_DIR": str(Path(logs_dir).resolve()),
        "LOCALVOICE_PRONUNCIATION_DIR": str(pronunciation),
        "HF_HUB_OFFLINE": "1",
        "TRANSFORMERS_OFFLINE": "1",
    }

