"""Validated Pro production catalog boundary.

The source VoiceLibrary remains authoritative for labels and metadata. This
manifest limits the active Recap runtime to profiles validated against the
canonical staging library and frozen Pro model/routes.
"""

from __future__ import annotations

AUDITED_LANGUAGE_CODES = (
    "ko-KR",
    "vi-VN",
    "ja-JP",
    "en-US",
    "es-419",
    "es-ES",
    "pt-BR",
    "th-TH",
    "fil-PH",
)

AUDITED_ROUTES = {
    "vi-VN": "vieneu",
    "en-US": "qwen",
    "ko-KR": "qwen",
    "ja-JP": "qwen",
    "es-419": "qwen",
    "es-ES": "qwen",
    "pt-BR": "qwen",
    "th-TH": "vox_cuda",
    "fil-PH": "vox_cuda",
}

AUDITED_VOICE_IDS = {
    "ko-KR": (
        "ko_kr_sora",
        "ko_kr_parksun",
        "ko_kr_minju",
        "ko_kr_minho",
        "ko_kr_kimpar",
        "ko_kr_jura",
        "ko-KR_male_01",
    ),
    "vi-VN": (
        "vi_vn_duc_minh",
        "vi_vn_tuan_anh",
        "vi_vn_tony_duy",
        "vi_vn_huong_mai",
        "vi_vn_cam_hong",
        "vi_vn_mai_anh",
        "vi_vn_khanh_linh",
        "vi_vn_gia_huy",
        "vi_vn_minh_quan",
        "vi_vn_ngoc_han",
    ),
    "ja-JP": (
        "ja_jp_yuri",
        "ja_jp_tusai",
        "ja_jp_nakoji",
        "ja_jp_minti",
        "ja_jp_kenshi",
        "ja_jp_hayki",
        "ja_jp_ayjen",
    ),
    "en-US": (
        "en_us_alisha",
        "en_us_vitorya_ms",
        "en_us_ryan",
        "en_us_mr_binas",
        "en_us_micah",
        "en_us_mia",
        "en_us_lynda",
        "en_us_krisen",
        "en_us_jayce",
        "en_us_jack_d",
        "en_us_hank",
        "en_us_emily",
    ),
    "es-419": (
        "es_419_minas",
        "es_419_migel",
        "es_419_miar",
        "es_419_maxi",
        "es_419_jenshi",
        "es_419_jack",
    ),
    "es-ES": (
        "es_es_tony",
        "es_es_tela",
        "es_es_maeta",
        "es_es_johny",
        "es_es_evans",
        "es_es_alex",
    ),
    "pt-BR": (
        "pt_br_aderamis",
        "pt_br_wise",
        "pt_br_ritaki",
        "pt_br_athur",
    ),
    "th-TH": (
        "th_th_serene",
        "th_th_frien",
        "th_th_ener",
        "th_th_cheer",
    ),
    "fil-PH": (
        "fil_ph_yamari",
        "fil_ph_milesto",
        "fil_ph_jousi",
        "fil_ph_jerudar",
        "fil_ph_belsa",
        "fil_ph_alemus",
    ),
}

AUDITED_VOICE_COUNT = sum(len(items) for items in AUDITED_VOICE_IDS.values())

