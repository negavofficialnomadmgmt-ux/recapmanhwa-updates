"""Isolated worker that delegates to the canonical TTS Studio Pro pipeline."""

from __future__ import annotations

import argparse
import json
import os
import shutil
import sys
import time
from pathlib import Path
from typing import Any

from voice_runtime.config import ProRuntimeConfig, load_runtime_config, runtime_environment
from voice_runtime.device_policy import (
    FALLBACK_NOTICE,
    is_cuda_error,
    mark_cuda_unavailable,
    release_cuda_memory,
    resolve_tts_device,
)
from voice_runtime.errors import ProVoiceRuntimeError, classify_exception
from voice_runtime.hybrid_hooks import apply_hybrid_hooks
from voice_runtime.manifest import (
    AUDITED_LANGUAGE_CODES,
    AUDITED_ROUTES,
    AUDITED_VOICE_COUNT,
    AUDITED_VOICE_IDS,
)
from voice_runtime.sea_g2p_loader import ensure_sea_g2p_importable
from voice_runtime.version import BACKEND_ID, QUALITY_FINGERPRINT, RUNTIME_VERSION


def _atomic_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def _apply_environment(
    config: ProRuntimeConfig,
    *,
    work_dir: Path,
    cache_dir: Path,
    output_dir: Path,
    logs_dir: Path,
) -> None:
    os.environ.update(
        runtime_environment(
            config,
            work_dir=work_dir,
            cache_dir=cache_dir,
            output_dir=output_dir,
            logs_dir=logs_dir,
        )
    )
    os.environ["PATH"] = os.pathsep.join(
        [str(config.ffmpeg_dir), str(config.pydeps_dir / "torch" / "lib"), os.environ.get("PATH", "")]
    )
    for candidate in (config.source_root, config.pydeps_dir):
        text = str(candidate)
        if text not in sys.path:
            sys.path.insert(0, text)
    ensure_sea_g2p_importable(config.sea_g2p_package_dir)
    apply_hybrid_hooks()


_PRO_CACHE: dict[str, Any] | None = None
_ENGINE_MANAGER: Any = None


def _reset_engine_manager(loaded: dict[str, Any]) -> Any:
    global _ENGINE_MANAGER
    manager = loaded.get("engine_manager")
    closer = getattr(manager, "unload", None)
    if callable(closer):
        try:
            closer()
        except Exception:
            pass
    release_cuda_memory()
    from voice.engine_manager import VoiceEngineManager

    _ENGINE_MANAGER = VoiceEngineManager(loaded["settings"])
    loaded["engine_manager"] = _ENGINE_MANAGER
    return _ENGINE_MANAGER


def _retry_scene_on_cpu(job, profile, settings, loaded: dict[str, Any], work_dir: Path, scene_id: str, error: str) -> str:
    mark_cuda_unavailable(error)
    _worker_log(work_dir, "CUDA FALLBACK CPU", scene_id=scene_id, error=error, pid=os.getpid())
    manager = _reset_engine_manager(loaded)
    for item in getattr(job, "items", []) or []:
        if getattr(item, "status", "") == "failed":
            item.status = "pending"
            item.error = None
    from voice.batch import run_batch_job

    run_batch_job(job, profile, settings, mode="run", engine_manager=manager)
    return FALLBACK_NOTICE


def _worker_log(work_dir: Path, event: str, **fields: Any) -> None:
    folder = work_dir / "logs"
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / "tts_worker.log"
    row = {"ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "event": event, **fields}
    try:
        with path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(row, ensure_ascii=False, default=str) + "\n")
    except OSError:
        pass


def _load_pro(config: ProRuntimeConfig, request: dict[str, Any]):
    global _PRO_CACHE
    root = Path(str(request.get("runtime_work_dir") or "")).resolve()
    cache = Path(str(request.get("runtime_cache_dir") or "")).resolve()
    output = root / "exports"
    logs = root / "logs"
    for path in (root, cache, output, logs):
        path.mkdir(parents=True, exist_ok=True)
    _apply_environment(
        config,
        work_dir=root,
        cache_dir=cache,
        output_dir=output,
        logs_dir=logs,
    )
    if _PRO_CACHE is not None:
        return _PRO_CACHE

    _worker_log(root, "MODEL LOAD START", pid=os.getpid())
    from config.edition import engine_for_locale
    from config.settings import load_settings
    from voice.engine_manager import VoiceEngineManager
    from voice.library_service import VoiceLibrary

    settings = load_settings()
    library = VoiceLibrary(settings)
    for language, expected in AUDITED_ROUTES.items():
        actual = engine_for_locale(language)
        if actual != expected:
            raise ProVoiceRuntimeError(
                "backend_route_mismatch",
                f"Frozen Pro route mismatch for {language}: expected {expected}, got {actual}",
            )
    global _ENGINE_MANAGER
    _ENGINE_MANAGER = VoiceEngineManager(settings)
    _PRO_CACHE = {
        "settings": settings,
        "library": library,
        "engine_for_locale": engine_for_locale,
        "engine_manager": _ENGINE_MANAGER,
    }
    _worker_log(root, "MODEL LOAD END", pid=os.getpid(), reused=False)
    return _PRO_CACHE


def _audited_profiles(library) -> tuple[list[Any], list[str]]:
    discovered = {(profile.language, profile.id): profile for profile in library.profiles}
    profiles: list[Any] = []
    missing: list[str] = []
    for language in AUDITED_LANGUAGE_CODES:
        for voice_id in AUDITED_VOICE_IDS[language]:
            profile = discovered.get((language, voice_id))
            if profile is None:
                missing.append(f"{language}/{voice_id}")
            else:
                profiles.append(profile)
    if missing:
        raise ProVoiceRuntimeError(
            "invalid_voice_metadata",
            "The canonical staging library is missing audited Pro voices.",
            missing=missing,
        )
    audited_keys = {(profile.language, profile.id) for profile in profiles}
    ignored = sorted(
        f"{profile.language}/{profile.id}"
        for profile in library.profiles
        if (profile.language, profile.id) not in audited_keys
    )
    if len(profiles) != AUDITED_VOICE_COUNT:
        raise ProVoiceRuntimeError(
            "invalid_voice_metadata",
            f"Expected {AUDITED_VOICE_COUNT} audited voices, loaded {len(profiles)}.",
        )
    return profiles, ignored


def _profile_for(library, language: str, voice_id: str):
    if language not in AUDITED_LANGUAGE_CODES:
        raise ProVoiceRuntimeError("unsupported_language", f"Unsupported Pro language: {language}")
    if voice_id not in AUDITED_VOICE_IDS[language]:
        raise ProVoiceRuntimeError(
            "unsupported_voice",
            f"Voice {voice_id!r} is not in the audited {language} runtime inventory.",
        )
    profile = library.get_profile(language, voice_id)
    if profile is None:
        raise ProVoiceRuntimeError(
            "unsupported_voice",
            f"Voice profile not found: {language}/{voice_id}",
        )
    return profile


def _catalog(config: ProRuntimeConfig, request: dict[str, Any]) -> dict[str, Any]:
    loaded = _load_pro(config, request)
    library = loaded["library"]
    engine_for_locale = loaded["engine_for_locale"]
    profiles, ignored = _audited_profiles(library)
    by_language: dict[str, list[Any]] = {code: [] for code in AUDITED_LANGUAGE_CODES}
    for profile in profiles:
        by_language[profile.language].append(profile)
    labels = dict(library.language_options())
    return {
        "success": True,
        "backend": BACKEND_ID,
        "runtime_version": RUNTIME_VERSION,
        "quality_fingerprint": QUALITY_FINGERPRINT,
        "languages": [
            {
                "code": code,
                "label": labels.get(code, code),
                "engine": engine_for_locale(code),
                "voice_count": len(by_language[code]),
            }
            for code in AUDITED_LANGUAGE_CODES
        ],
        "voices": [
            {
                "language": profile.language,
                "voice_id": profile.id,
                "label": profile.visible_name(),
                "gender": profile.gender,
                "engine": engine_for_locale(profile.language),
                "metadata_path": str(Path(profile.profile_dir) / "voice.json"),
                "reference_path": str(profile.reference_path),
                "preview_path": str(profile.preview_path),
            }
            for profile in sorted(profiles, key=lambda item: (item.language, item.visible_name().casefold()))
        ],
        "ignored_unvalidated_profiles": ignored,
    }


def _preview(config: ProRuntimeConfig, request: dict[str, Any]) -> dict[str, Any]:
    loaded = _load_pro(config, request)
    library = loaded["library"]
    engine_for_locale = loaded["engine_for_locale"]
    language = str(request.get("language") or "")
    voice_id = str(request.get("voice_id") or "")
    profile = _profile_for(library, language, voice_id)

    from voice.preview_file import bundled_preview_path

    path = bundled_preview_path(profile)
    if path is None:
        raise ProVoiceRuntimeError(
            "invalid_voice_metadata",
            f"Bundled Pro preview is missing for {language}/{voice_id}",
        )
    return {
        "success": True,
        "backend": BACKEND_ID,
        "preview_path": str(path),
        "preview_mode": "bundled",
        "engine": engine_for_locale(language),
        "speed_applied": False,
    }


def _atomic_copy(source: Path, target: Path) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_name(f"{target.stem}.tmp{target.suffix}")
    shutil.copy2(source, temporary)
    os.replace(temporary, target)


def _render_scene(config: ProRuntimeConfig, request: dict[str, Any]) -> dict[str, Any]:
    loaded = _load_pro(config, request)
    settings = loaded["settings"]
    library = loaded["library"]
    engine_for_locale = loaded["engine_for_locale"]
    engine_manager = loaded["engine_manager"]
    scene_id = str(request.get("scene_id") or "").strip()
    language = str(request.get("language") or "").strip()
    voice_id = str(request.get("voice_id") or "").strip()
    raw_text = request.get("text")
    if raw_text is None:
        text = ""
    else:
        text = str(raw_text).replace("\x00", "").strip()
    speed = float(request.get("speed") if request.get("speed") is not None else 1.0)
    output_path = Path(str(request.get("output_path") or "")).resolve()
    work_dir = Path(str(request.get("runtime_work_dir") or output_path.parent)).resolve()
    if not scene_id:
        raise ProVoiceRuntimeError("synthesis_failure", "scene_id is required.")
    if not text:
        raise ProVoiceRuntimeError("synthesis_failure", f"Narration is empty for {scene_id}.")
    _worker_log(
        work_dir,
        "SCENE START",
        scene_id=scene_id,
        text_length=len(text),
        voice=voice_id,
        language=language,
        pid=os.getpid(),
    )
    if not (0.5 <= speed <= 2.0):
        raise ProVoiceRuntimeError("synthesis_failure", f"Speed must be between 0.50 and 2.00: {speed}")
    if output_path.suffix.casefold() != ".mp3":
        raise ProVoiceRuntimeError("export_failure", "Pro scene output must be an MP3 file.")

    profile = _profile_for(library, language, voice_id)
    settings.speed = speed
    engine_name = engine_for_locale(language)
    decision = resolve_tts_device(engine_name, voice=voice_id, language=language)
    _worker_log(
        work_dir,
        "DEVICE SELECT",
        language=language,
        voice=voice_id,
        engine=engine_name,
        backend=decision.backend,
        cuda_available=decision.cuda_available,
        cuda_supported=decision.cuda_supported,
        selected_device=decision.device,
        selection_reason=decision.reason,
        precision=decision.precision,
        pid=os.getpid(),
    )
    scratch = Path(str(request.get("scene_scratch_dir") or "")).resolve()
    scratch.mkdir(parents=True, exist_ok=True)
    source_path = scratch / f"{scene_id}.txt"
    source_path.write_text(text, encoding="utf-8")
    job = None
    started = time.perf_counter()
    fallback_notice = ""
    try:
        from script.loader import load_script
        from script.synth_plan import build_active_plan
        from voice.batch import run_batch_job
        from voice.export import export_job
        from voice.job import create_job

        document = load_script(source_path)
        plan = build_active_plan(
            document,
            language=language,
            voice_id=voice_id,
        )
        if not plan.chunks:
            raise ProVoiceRuntimeError("synthesis_failure", f"No speech chunks produced for {scene_id}.")
        job = create_job(
            settings=settings,
            document=document,
            profile=profile,
            language=language,
            chunks=plan.chunks,
            plan_id=plan.plan_id,
        )
        job = run_batch_job(job, profile, settings, mode="run", engine_manager=engine_manager)
        if job.status != "completed" or job.failed_chunks:
            errors = [str(item.error) for item in job.items if item.error]
            joined = " ".join(errors)
            if decision.device == "cuda" and (any(is_cuda_error(RuntimeError(err)) for err in errors) or is_cuda_error(RuntimeError(joined))):
                fallback_notice = _retry_scene_on_cpu(
                    job,
                    profile,
                    settings,
                    loaded,
                    work_dir,
                    scene_id,
                    joined,
                )
            else:
                raise ProVoiceRuntimeError(
                    "synthesis_failure",
                    f"Pro synthesis failed for {scene_id}.",
                    job_status=job.status,
                    failed_chunks=job.failed_chunks,
                    errors=errors,
                )
        if job.status != "completed" or job.failed_chunks:
            errors = [str(item.error) for item in job.items if item.error]
            raise ProVoiceRuntimeError(
                "synthesis_failure",
                f"Pro synthesis failed for {scene_id}.",
                job_status=job.status,
                failed_chunks=job.failed_chunks,
                errors=errors,
            )
        export_dir = scratch / "export"
        exported = export_job(job, settings, output_dir=export_dir)
        _atomic_copy(Path(exported.mp3_path), output_path)
        Path(exported.srt_path).unlink(missing_ok=True)
        used_engine = engine_manager.get_engine(language=language) if engine_manager is not None else None
        runtime_device = str(getattr(used_engine, "runtime_device", decision.device) or decision.device)
        notice = fallback_notice or str(getattr(used_engine, "_cpu_fallback_notice", "") or "")
        result = {
            "success": True,
            "backend": BACKEND_ID,
            "runtime_version": RUNTIME_VERSION,
            "scene_id": scene_id,
            "audio_path": str(output_path),
            "duration": float(exported.duration),
            "sample_rate": int(exported.sample_rate),
            "channels": int(exported.channels),
            "bitrate_kbps": int(exported.bitrate_kbps),
            "engine": engine_name,
            "internal_chunk_count": len(plan.chunks),
            "job_id": job.job_id,
            "elapsed_seconds": round(time.perf_counter() - started, 3),
            "selected_device": runtime_device,
            "selection_reason": decision.reason,
            "device_notice": notice,
        }
        shutil.rmtree(job.job_dir, ignore_errors=True)
        shutil.rmtree(scratch, ignore_errors=True)
        _worker_log(
            work_dir,
            "SCENE DONE",
            scene_id=scene_id,
            device=runtime_device,
            pid=os.getpid(),
        )
        return result
    except ProVoiceRuntimeError as exc:
        if decision.device == "cuda" and is_cuda_error(exc) and job is not None:
            fallback_notice = _retry_scene_on_cpu(
                job, profile, settings, loaded, work_dir, scene_id, str(exc)
            )
            if job.status == "completed" and not job.failed_chunks:
                from voice.export import export_job

                export_dir = scratch / "export"
                exported = export_job(job, settings, output_dir=export_dir)
                _atomic_copy(Path(exported.mp3_path), output_path)
                Path(exported.srt_path).unlink(missing_ok=True)
                _worker_log(work_dir, "SCENE DONE", scene_id=scene_id, device="cpu", fallback=True, pid=os.getpid())
                shutil.rmtree(job.job_dir, ignore_errors=True)
                shutil.rmtree(scratch, ignore_errors=True)
                return {
                    "success": True,
                    "backend": BACKEND_ID,
                    "runtime_version": RUNTIME_VERSION,
                    "scene_id": scene_id,
                    "audio_path": str(output_path),
                    "duration": float(exported.duration),
                    "sample_rate": int(exported.sample_rate),
                    "channels": int(exported.channels),
                    "bitrate_kbps": int(exported.bitrate_kbps),
                    "engine": engine_name,
                    "internal_chunk_count": 0,
                    "job_id": job.job_id,
                    "elapsed_seconds": round(time.perf_counter() - started, 3),
                    "selected_device": "cpu",
                    "selection_reason": "CUDA failure fallback CPU",
                    "device_notice": fallback_notice,
                }
        _worker_log(work_dir, "SCENE FAILED", scene_id=scene_id, error=str(exc), pid=os.getpid())
        raise
    except Exception as exc:
        payload = classify_exception(exc)
        if decision.device == "cuda" and is_cuda_error(exc) and job is not None:
            try:
                fallback_notice = _retry_scene_on_cpu(
                    job, profile, settings, loaded, work_dir, scene_id, payload.message
                )
                if job.status == "completed" and not job.failed_chunks:
                    from voice.export import export_job

                    export_dir = scratch / "export"
                    exported = export_job(job, settings, output_dir=export_dir)
                    _atomic_copy(Path(exported.mp3_path), output_path)
                    Path(exported.srt_path).unlink(missing_ok=True)
                    shutil.rmtree(job.job_dir, ignore_errors=True)
                    shutil.rmtree(scratch, ignore_errors=True)
                    _worker_log(work_dir, "SCENE DONE", scene_id=scene_id, device="cpu", fallback=True, pid=os.getpid())
                    return {
                        "success": True,
                        "backend": BACKEND_ID,
                        "runtime_version": RUNTIME_VERSION,
                        "scene_id": scene_id,
                        "audio_path": str(output_path),
                        "duration": float(exported.duration),
                        "sample_rate": int(exported.sample_rate),
                        "channels": int(exported.channels),
                        "bitrate_kbps": int(exported.bitrate_kbps),
                        "engine": engine_name,
                        "internal_chunk_count": 0,
                        "job_id": job.job_id,
                        "elapsed_seconds": round(time.perf_counter() - started, 3),
                        "selected_device": "cpu",
                        "selection_reason": "CUDA failure fallback CPU",
                        "device_notice": fallback_notice,
                    }
            except Exception:
                pass
        _worker_log(work_dir, "SCENE FAILED", scene_id=scene_id, error=payload.message, pid=os.getpid())
        raise ProVoiceRuntimeError(payload.code, payload.message, **payload.details) from exc
    finally:
        source_path.unlink(missing_ok=True)


def _dispatch(config: ProRuntimeConfig, request: dict[str, Any]) -> dict[str, Any]:
    command = str(request.get("command") or "")
    if command == "catalog":
        return _catalog(config, request)
    if command == "preview":
        return _preview(config, request)
    if command == "render_scene":
        return _render_scene(config, request)
    raise ProVoiceRuntimeError("backend_init_failure", f"Unknown Pro runtime command: {command}")


def _serve_loop(config: ProRuntimeConfig, serve_dir: Path) -> int:
    inbox = serve_dir / "inbox"
    inbox.mkdir(parents=True, exist_ok=True)
    shutdown = serve_dir / "shutdown"
    heartbeat = serve_dir / "heartbeat.json"
    _worker_log(serve_dir, "SERVE START", pid=os.getpid())
    while not shutdown.is_file():
        _atomic_json(heartbeat, {"pid": os.getpid(), "ts": time.time(), "alive": True})
        requests = sorted(inbox.glob("*.request.json"))
        if not requests:
            time.sleep(0.05)
            continue
        request_path = requests[0]
        result_path = serve_dir / "inbox" / request_path.name.replace(".request.json", ".result.json")
        try:
            request = json.loads(request_path.read_text(encoding="utf-8"))
            if not isinstance(request, dict):
                raise ProVoiceRuntimeError("backend_init_failure", "Worker request must be an object.")
            payload = _dispatch(config, request)
            _atomic_json(result_path, payload)
        except BaseException as exc:
            error = classify_exception(exc)
            _atomic_json(
                result_path,
                {
                    "success": False,
                    "backend": BACKEND_ID,
                    "runtime_version": RUNTIME_VERSION,
                    "error": error.to_dict(),
                },
            )
            if isinstance(exc, (KeyboardInterrupt, SystemExit)):
                request_path.unlink(missing_ok=True)
                return 1
        request_path.unlink(missing_ok=True)
    _worker_log(serve_dir, "SERVE STOP", pid=os.getpid())
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="RecapManhwa TTS Studio Pro runtime worker")
    parser.add_argument("--config", required=True)
    parser.add_argument("--request")
    parser.add_argument("--result")
    parser.add_argument("--serve")
    args = parser.parse_args(argv)
    try:
        config = load_runtime_config(Path(args.config))
        if args.serve:
            return _serve_loop(config, Path(args.serve).resolve())
        if not args.request or not args.result:
            raise ProVoiceRuntimeError("backend_init_failure", "Worker --request and --result are required.")
        result_path = Path(args.result).resolve()
        request = json.loads(Path(args.request).read_text(encoding="utf-8"))
        if not isinstance(request, dict):
            raise ProVoiceRuntimeError("backend_init_failure", "Worker request must be an object.")
        payload = _dispatch(config, request)
        _atomic_json(result_path, payload)
        return 0
    except BaseException as exc:
        error = classify_exception(exc)
        if args.result:
            _atomic_json(
                Path(args.result).resolve(),
                {
                    "success": False,
                    "backend": BACKEND_ID,
                    "runtime_version": RUNTIME_VERSION,
                    "error": error.to_dict(),
                },
            )
        return 1


if __name__ == "__main__":
    raise SystemExit(main())

