"""Versioned shared boundary around the canonical TTS Studio Pro engine."""

from voice_runtime.version import BACKEND_ID, QUALITY_FINGERPRINT, RUNTIME_VERSION

__all__ = ["BACKEND_ID", "QUALITY_FINGERPRINT", "RUNTIME_VERSION"]

