"""Isolated loader for the exact sea-g2p dependency frozen into Pro."""

from __future__ import annotations

import base64
import hashlib
import importlib.util
import os
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from voice_runtime.errors import ProVoiceRuntimeError

CANONICAL_DISTRIBUTION = "sea-g2p"
CANONICAL_VERSION = "0.9.1"
DIST_INFO_DIRECTORY = f"sea_g2p-{CANONICAL_VERSION}.dist-info"

# These are the hashes and sizes recorded by the canonical 0.9.1 wheel install
# used by packaging/tts_studio.spec to build TTS Studio Pro.
CANONICAL_FILES: dict[str, tuple[int, str]] = {
    "__init__.py": (191, "g0ENVXkOyycZoVayTtRijQhnlMeiBbJq94s545foYAU"),
    "g2p.py": (2698, "Jio3Z_4Sdgyw-wFSPJThTg1QeOqCjzTodwKj22KnoAc"),
    "normalizer.py": (4173, "GFLkI-W0-fNBLVvh2iJ2LNrzeKbOGAVg7v-XYLTgIuQ"),
    "pipeline.py": (1569, "xqFswihvYKRiimtlj9ydejxo_UJP6yyhrdIO0kminBc"),
    "sea_g2p.bin": (62829820, "Q0bmkNBxHrxSMeekLFyIqvbkA3folLRhfAGP2BxvQJY"),
    "sea_g2p_rs.pyd": (5723136, "SlriK-Bpx1j7_wPglL1n4EKBPovNO0IHnn2l2NcflCI"),
}

_VALIDATED: set[Path] = set()
_DLL_DIRECTORY_HANDLES: list[Any] = []


@dataclass(frozen=True)
class SeaG2PIdentity:
    distribution: str
    version: str
    package_dir: str
    file_count: int

    def to_dict(self) -> dict[str, object]:
        return {
            "distribution": self.distribution,
            "version": self.version,
            "package_dir": self.package_dir,
            "file_count": self.file_count,
        }


def _record_digest(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return base64.urlsafe_b64encode(digest.digest()).decode("ascii").rstrip("=")


def _metadata_version(package_dir: Path) -> str:
    metadata = package_dir.parent / DIST_INFO_DIRECTORY / "METADATA"
    if not metadata.is_file():
        raise ProVoiceRuntimeError(
            "missing_runtime_dependency",
            f"Canonical {CANONICAL_DISTRIBUTION} metadata is missing.",
            path=str(metadata),
        )
    try:
        lines = metadata.read_text(encoding="utf-8").splitlines()
    except OSError as exc:
        raise ProVoiceRuntimeError(
            "missing_runtime_dependency",
            f"Cannot read canonical {CANONICAL_DISTRIBUTION} metadata: {exc}",
            path=str(metadata),
        ) from exc
    for line in lines:
        if line.startswith("Version:"):
            return line.split(":", 1)[1].strip()
    raise ProVoiceRuntimeError(
        "runtime_dependency_version_mismatch",
        f"Canonical {CANONICAL_DISTRIBUTION} metadata has no Version field.",
        path=str(metadata),
    )


def validate_sea_g2p_package(package_dir: Path) -> SeaG2PIdentity:
    root = Path(package_dir).resolve()
    if root.name != "sea_g2p" or not root.is_dir():
        raise ProVoiceRuntimeError(
            "missing_runtime_dependency",
            "sea_g2p_package_dir must point to the exact sea_g2p package directory.",
            path=str(root),
        )
    version = _metadata_version(root)
    if version != CANONICAL_VERSION:
        raise ProVoiceRuntimeError(
            "runtime_dependency_version_mismatch",
            f"Expected {CANONICAL_DISTRIBUTION} {CANONICAL_VERSION}, found {version}.",
            path=str(root),
        )
    if root not in _VALIDATED:
        missing: list[str] = []
        mismatched: dict[str, dict[str, object]] = {}
        for name, (expected_size, expected_digest) in CANONICAL_FILES.items():
            path = root / name
            if not path.is_file():
                missing.append(name)
                continue
            actual_size = path.stat().st_size
            actual_digest = _record_digest(path)
            if actual_size != expected_size or actual_digest != expected_digest:
                mismatched[name] = {
                    "expected_size": expected_size,
                    "actual_size": actual_size,
                    "expected_sha256_record": expected_digest,
                    "actual_sha256_record": actual_digest,
                }
        if missing:
            raise ProVoiceRuntimeError(
                "missing_runtime_dependency",
                f"Canonical {CANONICAL_DISTRIBUTION} package is incomplete.",
                path=str(root),
                missing=missing,
            )
        if mismatched:
            raise ProVoiceRuntimeError(
                "runtime_dependency_version_mismatch",
                f"{CANONICAL_DISTRIBUTION} {CANONICAL_VERSION} fingerprint mismatch.",
                path=str(root),
                mismatched=mismatched,
            )
        _VALIDATED.add(root)
    return SeaG2PIdentity(
        distribution=CANONICAL_DISTRIBUTION,
        version=version,
        package_dir=str(root),
        file_count=len(CANONICAL_FILES),
    )


def ensure_sea_g2p_importable(package_dir: Path) -> SeaG2PIdentity:
    """Register only sea_g2p; never add its site-packages parent to sys.path."""
    identity = validate_sea_g2p_package(package_dir)
    root = Path(identity.package_dir)
    existing = sys.modules.get("sea_g2p")
    if existing is not None:
        existing_file = Path(str(getattr(existing, "__file__", ""))).resolve()
        if root not in (existing_file, *existing_file.parents):
            raise ProVoiceRuntimeError(
                "runtime_dependency_version_mismatch",
                "A different sea_g2p implementation is already loaded.",
                expected_path=str(root),
                actual_path=str(existing_file),
            )
        return identity

    dll_handle = None
    add_dll_directory = getattr(os, "add_dll_directory", None)
    if callable(add_dll_directory):
        try:
            dll_handle = add_dll_directory(str(root))
        except OSError:
            dll_handle = None

    spec = importlib.util.spec_from_file_location(
        "sea_g2p",
        root / "__init__.py",
        submodule_search_locations=[str(root)],
    )
    if spec is None or spec.loader is None:
        raise ProVoiceRuntimeError(
            "missing_runtime_dependency",
            "Cannot construct the canonical sea_g2p import specification.",
            path=str(root),
        )
    module = importlib.util.module_from_spec(spec)
    sys.modules["sea_g2p"] = module
    try:
        spec.loader.exec_module(module)
    except BaseException as exc:
        for name in tuple(sys.modules):
            if name == "sea_g2p" or name.startswith("sea_g2p."):
                sys.modules.pop(name, None)
        if dll_handle is not None:
            dll_handle.close()
        raise ProVoiceRuntimeError(
            "missing_runtime_dependency",
            f"Cannot load canonical {CANONICAL_DISTRIBUTION} {CANONICAL_VERSION}: {exc}",
            path=str(root),
        ) from exc
    if dll_handle is not None:
        _DLL_DIRECTORY_HANDLES.append(dll_handle)
    return identity
